<template>
	<view class="content">
		<view class="content">
			<image class="logo" :src="avatar"></image>
			<view class="info">
				<view class="appname">{{appName}}</view>
				<view class="version">{{versionName}}</view>
			</view>
			<input v-model="account" placeholder="请输入账号" class="input_css" />
			<input password="true" v-model="password" placeholder="请输入密码" class="input_css" />
			<view v-if="error" class="error">{{error}}</view>
			<view class="btn" @click="doLogin">{{loginBtnText}}</view>			
			<view class="btn_un" @click="doBack">{{unLoginBtnText}}</view>			
		</view>
	</view>
</template>

<script>
	const app = getApp();
	export default{
		data(){
			return{
				account:undefined,
				password:undefined,
				error:"",
			}
		},
		props:{
			avatar:{
				type:String,
				default:"https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fdiy.qqjay.com%2Fu%2Ffiles%2F2012%2F0217%2Fb693a3b6d232ffe861da22287c888729.jpg&refer=http%3A%2F%2Fdiy.qqjay.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1623147216&t=a2af93e9fdced335cca87e4a4c77ca24",
			},
			loginBtnText:{
				type:String,
				default:"登录 / 注册"
			},
			unLoginBtnText:{
				type:String,
				default:"暂不登录"
			},
			appName:{
				type:String,
				default:"登录模块"
			},
			versionName:{
				type:String,
				default:"v1.0"
			},
			checkVaild:{
				type:Boolean,
				default:true
			}
		},
		methods:{
			doLogin(){
				// 是否校验账号密码完整性
				if(this.$props.checkVaild){
					if(!this.account){
						this.error = "请输入账号！";
						return;
					}
					if(!this.password){
						this.error = "请输入密码！";
						return;
					}
				}
				
				this.$emit("doLogin",{account:this.account,password:this.password});
			},
			doBack(){
				this.$emit("doCancel",{});
				// uni.navigateBack({
				// 	delta:1,
				// })
			}
		}
	}
</script>

<style>
	@import url("login.css");
</style>
